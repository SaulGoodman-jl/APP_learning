package com.example.android.camera2.basic

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ViewGroup
import com.yatoooon.screenadaptation.ScreenAdapterTools

class ImgListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_img_list)
        ScreenAdapterTools.getInstance().loadView(window.decorView as ViewGroup)
    }
}