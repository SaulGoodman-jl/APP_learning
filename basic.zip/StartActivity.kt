package com.example.android.camera2.basic

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import androidx.annotation.RequiresPermission.Write
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class StartActivity : AppCompatActivity() {

    private val CAMERA_PERMISSION_CODE = 100
    private val WRITE_PERMISSION_CODE = 300

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)

        requestCameraPermission()
        requestWritePermission()

        try{
            Thread.sleep(1000)
        }catch(e:Exception){
            Log.e("AirBus",e.message.toString())
        }

        //获取摄像头列表
        val intent : Intent = Intent(this,CameraActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_CODE
            )
        }
    }

    private fun requestWritePermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                WRITE_PERMISSION_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            CAMERA_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("AirBus", "CAMERA Permission was GRANTED")
                } else {
                    Log.e("AirBus", "CAMERA Permission was denied")
                }
            }
            WRITE_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("AirBus", "WRITE Permission was GRANTED")
                } else {
                    Log.e("AirBus", "WRITE Permission was denied")
                }
            }
        }
    }

    private fun px2dp(pxValue:Int): Int {
        val scale = getResources().getDisplayMetrics().density
        Log.e("airbus","the scale = %f".format(scale))
        return (pxValue / scale + 0.5f).toInt()
    }
}