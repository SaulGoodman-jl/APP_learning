package com.example.android.camera2.basic

import android.app.Application
import android.util.Log
import com.yatoooon.screenadaptation.ScreenAdapterTools

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.e("AirBus","App 初始化..............")
        ScreenAdapterTools.init(this);
    }
}